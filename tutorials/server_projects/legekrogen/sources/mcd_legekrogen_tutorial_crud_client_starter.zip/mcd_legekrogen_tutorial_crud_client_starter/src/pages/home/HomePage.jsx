import StyleGuide from "../../components/common/StyleGuide/StyleGuide";

const HomePage = () => {

    return (
        <div>
            <StyleGuide></StyleGuide>
        </div>
    );
};

export default HomePage;