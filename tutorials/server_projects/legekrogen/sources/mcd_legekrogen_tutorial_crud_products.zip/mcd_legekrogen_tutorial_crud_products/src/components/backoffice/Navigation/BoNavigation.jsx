import { Link, NavLink } from 'react-router-dom';
import styles from './bonavigation.module.css'
import { icons } from '../../../services/icons';

const BoNavigation = () => {

    return (
        <div className={styles.navigation}>
            <div className={styles.brand}>
                <Link to={"/"} className={styles.banner}>
         
                   Backoffice Navigation
                
                </Link>
            </div>
            <div>
                <div className={styles.routes}>

                    <NavLink to="/backoffice/products" className={({ isActive }) => (isActive ? styles.active : null)}>

                        {icons['FaProductHunt']}  <span className={styles.title}>Backoffice Products</span>

                    </NavLink>

                    <NavLink to="/backoffice/subscribers" className={({ isActive }) => (isActive ? styles.active : null)}>

                        {icons['FaProductHunt']}  <span className={styles.title}>Backoffice Subscribers</span>

                    </NavLink>
                    
                </div>

            </div>
        </div>
    );

};
export default BoNavigation;