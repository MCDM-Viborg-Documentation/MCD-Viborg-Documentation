import { useEffect, useState } from 'react';
import styles from './products.module.css'
import PrintJson from '../../common/PrintJSON/PrintJson';
import useTinyFetch from '../../../hooks/tinyFetch.hook';
import { Link } from 'react-router-dom';

const Product = ({product}) => {

    return <div className={styles.product}>
    
        <PrintJson jsonobj={product} headline={product.title}></PrintJson>
        
        <Link to={`/products/${product._id}`}>Product Page</Link>
    </div>

}

const ProductList = ({products}) => {

    return (
        <div className={styles.list}>

            {products.map( (product) => {

                return <Product key={product._id} product={product}></Product>

            } )}

        </div>
    )

}

const Products = () => {

    const [products, setProducts] = useState([]);
    const {data, fetchData} = useTinyFetch()

    useEffect( () => {

        fetchData('/products');

    }, [])

    useEffect( () => {

        setProducts(data)

    }, [data])

    return (

        <div className={styles.products}>


           <ProductList products={products}></ProductList>


        </div>

    );
};

export default Products;