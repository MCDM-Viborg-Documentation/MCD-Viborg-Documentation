import { Link, NavLink } from 'react-router-dom';
import styles from './navigation.module.css'
import { icons } from '../../../services/icons';
const Navigation = () => {

    return (
        <div className={styles.navigation}>
            <div className={styles.brand}>
                <Link to={"/"} className={styles.banner}>
         
                   Functional Prototype
                
                </Link>
            </div>
            <div>
                <div className={styles.routes}>

                    <NavLink to="/" className={({ isActive }) => (isActive ? styles.active : null)}>

                        {icons['FaHouse']}  <span className={styles.title}>HOME</span>

                    </NavLink>

                    <NavLink to="/products" className={({ isActive }) => (isActive ? styles.active : null)}>

                        {icons['FaProductHunt']} <span className={styles.title}>PRODUCTS</span>

                    </NavLink>

                    <NavLink to="/reviews" className={({ isActive }) => (isActive ? styles.active : null)}>

                        {icons['FaCircleUser']} <span className={styles.title}>REVIEWS</span>

                    </NavLink>

                    <NavLink to="/subscribers" className={({ isActive }) => (isActive ? styles.active : null)}>

                        {icons['FaBullseye']} <span className={styles.title}>SUBSCRIBERS</span>

                    </NavLink>

                    <NavLink to="/backoffice" className={({ isActive }) => (isActive ? styles.active : null)}>

                        {icons['FaUserSecret']} <span className={styles.title}>BACKOFFICE</span>

                    </NavLink>
                </div>

            </div>
        </div>
    );

};
export default Navigation;