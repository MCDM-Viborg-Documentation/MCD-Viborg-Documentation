import Products from "../../components/products/Products/Products"

const ProductsPage = () => {

    return (
        <div>
            <Products></Products>
        </div>
    )

}

export default ProductsPage