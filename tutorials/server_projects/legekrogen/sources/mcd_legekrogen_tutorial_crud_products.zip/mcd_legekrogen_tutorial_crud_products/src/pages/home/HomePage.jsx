const HomePage = () => {

    return (
        <div>
            Start Parat!
        </div>
    );
};

export default HomePage;