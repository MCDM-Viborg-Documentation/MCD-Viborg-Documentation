import { useEffect, useState } from 'react';
import styles from './products.module.css'
import PrintJson from '../../common/PrintJSON/PrintJson';
import useTinyFetch from '../../../hooks/tinyFetch.hook';
import { Link } from 'react-router-dom';
import { icons } from '../../../services/icons';

const Product = ({product}) => {

    return <div className={styles.product}>
        
        <img src={product.image} />
        <div className={styles.content}>
            
            <h3>{product.title}</h3>
            <p>{product.description}</p>
            <p>{product.price} kr.</p>
        </div>
        
    </div>

}

const DebugProduct = ({product}) => {

    return <div className={styles.debugProduct}>
    
        <PrintJson jsonobj={product} headline={product.title}></PrintJson>
        
        <Link to={`/products/${product._id}`}>Product Page</Link>
    </div>

}

const ProductList = ({products, debugMode}) => {

    return (
        <div className={styles.list}>
            
            {products.map( (product) => {

                return debugMode ? <DebugProduct key={product._id} product={product}></DebugProduct> : <Product key={product._id} product={product}></Product>

            } )}

        </div>
    )

}

const Products = () => {

    const [products, setProducts] = useState([]);
    const [debugMode, setDebugMode] = useState(true);
    const {data, fetchData} = useTinyFetch()

    useEffect( () => {

        fetchData('/products');

    }, [])

    useEffect( () => {

        setProducts(data)

    }, [data])

    return (

        <div className={styles.products}>
            <div className={styles.debugBtn} onClick={ () => setDebugMode(!debugMode)}>{icons["FaWrench"]} TOGGLE {debugMode ? 'PRODUCT' : 'DEBUG'} MODE</div>

           <ProductList products={products} debugMode={debugMode}></ProductList>


        </div>

    );
};

export default Products;