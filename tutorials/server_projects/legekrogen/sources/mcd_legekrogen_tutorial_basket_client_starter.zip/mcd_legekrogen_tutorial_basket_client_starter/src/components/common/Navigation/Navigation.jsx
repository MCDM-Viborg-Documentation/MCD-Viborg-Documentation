import { Link, NavLink } from 'react-router-dom';
import styles from './navigation.module.css'
import { icons } from '../../../services/icons';
const Navigation = () => {

    return (
        <div className={styles.navigation}>
            <div className={styles.brand}>
                <Link to={"/"} className={styles.banner}>
         
                   Functional Prototype
                
                </Link>
            </div>
            <div>
                <div className={styles.routes}>

                    <NavLink to="/orderpage" className={({ isActive }) => (isActive ? styles.active : null)}>

                        {icons['FaBasketShopping']} <span className={`${styles.sticker} ${styles.show}`}>0</span> <span className={styles.title}>ORDER PAGE</span>

                    </NavLink>

                    <NavLink to="/" className={({ isActive }) => (isActive ? styles.active : null)}>

                        {icons['FaHouse']}  <span className={styles.title}>HOME</span>

                    </NavLink>

                    <NavLink to="/products" className={({ isActive }) => (isActive ? styles.active : null)}>

                        {icons['FaProductHunt']} <span className={styles.title}>PRODUCTS</span>

                    </NavLink>
                    
                </div>

            </div>
        </div>
    );

};
export default Navigation;