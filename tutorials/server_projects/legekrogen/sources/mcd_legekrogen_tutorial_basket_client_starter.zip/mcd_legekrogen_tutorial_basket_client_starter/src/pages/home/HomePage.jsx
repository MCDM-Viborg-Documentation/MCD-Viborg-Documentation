import StyleGuide from "../../components/common/StyleGuide/StyleGuide";

const HomePage = () => {

    return (
        <div>
                HOME PAGE
        </div>
    );
};

export default HomePage;