// Settings
export const serverPath = `http://localhost:3042`;

const settings = {};

export default settings;
