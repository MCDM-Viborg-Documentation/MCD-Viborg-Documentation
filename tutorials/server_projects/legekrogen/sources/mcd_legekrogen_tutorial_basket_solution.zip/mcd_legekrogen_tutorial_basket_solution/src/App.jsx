import { useRoutes } from "react-router-dom";

// Common Pages.
import HomePage from "./pages/home/HomePage";
import Navigation from "./components/common/Navigation/Navigation";
import Footer from "./components/common/Footer/Footer";
import ProductPage from "./pages/product/ProductPage";
import ProductsPage from "./pages/products/ProductsPage";

// Application
const App = () => {

  // Setting Up Routes
  const routes = useRoutes([
    {
      path: "/",
      element : <HomePage></HomePage>
    },
    {
      path: "/products",
      element : <ProductsPage></ProductsPage>
    },
    {
      path: "/products/:id",
      element : <ProductPage></ProductPage>
    },
    {
      path: "*",
      element : <div>NOT 404 FOUND</div>
    },
  ]);

  return <>
    <div>
      {/* GLOBAL NAVIGATION */}
        <Navigation></Navigation>
        <div className="globale-page-wrapper">
            {routes}
        </div>
       {/* GLOBAL FOOTER */}
       <Footer></Footer>
    </div>
  </>;

}

export default App;
