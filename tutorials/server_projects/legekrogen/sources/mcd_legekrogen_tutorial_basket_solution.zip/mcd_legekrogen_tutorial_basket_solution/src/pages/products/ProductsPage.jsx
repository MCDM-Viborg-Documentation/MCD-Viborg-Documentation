import Basket from "../../components/basket/Basket"
import Products from "../../components/products/Products/Products"

const ProductsPage = () => {

    return (
        <div>
            <Basket></Basket>
            <Products></Products>
        </div>
    )

}

export default ProductsPage