import { useEffect, useState } from 'react';
import styles from './products.module.css'
import PrintJson from '../../common/PrintJSON/PrintJson';
import useTinyFetch from '../../../hooks/tinyFetch.hook';
import { Link } from 'react-router-dom';
import { icons } from '../../../services/icons';
import { useLocalStorage } from '@uidotdev/usehooks';

const Product = ({product, addToBasket}) => {

    return <div className={styles.product}>
        
        <img src={product.image} />
        <div className={styles.content}>
            
            <h3>{product.title}</h3>
            <p>{product.description}</p>
            <p>{product.price} kr.</p>

            <button onClick={() => addToBasket(product._id)}>{icons["FaBasketShopping"]}</button>

        </div>
        
    </div>

}

const DebugProduct = ({product, addToBasket}) => {

    return <div className={styles.debugProduct}>
    
        <PrintJson jsonobj={product} headline={product.title}></PrintJson>
        
        <button onClick={() => addToBasket(product._id)}>{icons["FaBasketShopping"]}</button>
        
        <Link to={`/products/${product._id}`}>Product Page</Link>

    </div>

}

const ProductList = ({products, debugMode, addToBasket}) => {

    return (
        <div className={styles.list}>
            
            {products.map( (product) => {

                return debugMode ? <DebugProduct key={product._id} product={product} addToBasket={addToBasket}></DebugProduct> : <Product key={product._id} product={product} addToBasket={addToBasket}></Product>

            } )}

        </div>
    )

}

const Products = () => {

    const [products, setProducts] = useState([]);
    const [debugMode, setDebugMode] = useState(true);
    const {data, fetchData} = useTinyFetch()

    const [basket, saveBasket] = useLocalStorage("basket", []);

    useEffect( () => {

        fetchData('/products');

    }, [])

    useEffect( () => {

        setProducts(data)

    }, [data])


    const addToBasket = (id, quantity = 1) => {

        let basketItemIndex = basket.findIndex( (item) => item.id === id)

        console.log(basketItemIndex)

        if(basketItemIndex === -1){

            saveBasket([
                ...basket,
                {
                    id,
                    quantity
                }
            ])

        } else {

            basket[basketItemIndex].quantity += quantity

            saveBasket([
                ...basket
            ])
        }


        
    }

    return (

        <div className={styles.products}>
            <div className={styles.debugBtn} onClick={ () => setDebugMode(!debugMode)}>{icons["FaWrench"]} TOGGLE {debugMode ? 'PRODUCT' : 'DEBUG'} MODE</div>

           <ProductList products={products} debugMode={debugMode} addToBasket={addToBasket}></ProductList>


        </div>

    );
};

export default Products;