import { useLocalStorage } from '@uidotdev/usehooks';
import styles from './basket.module.css'
import { useEffect, useState } from 'react';
import useTinyFetch from '../../hooks/tinyFetch.hook';
import { GiConsoleController } from 'react-icons/gi';


const BasketItem = ({item, addToBasket, removeFromBasket, deleteFromBasket, product}) => {


    return <div className={styles.item}>

        <h5>{product.title}</h5>
        <img src={product.image} width={"50px"}></img>
        <p>{product.description}</p>
        <p>Pris {product.price} kr.</p>
        <p>Antal : <b>{item.quantity}</b></p>
        <p>Total : <b>{Math.ceil(item.quantity * product.price)} kr. ({item.quantity * product.price})</b></p>
        <button onClick={() => addToBasket(item.id)}>+</button>
        <button onClick={() => removeFromBasket(item.id)}>-</button>
        <button onClick={() => deleteFromBasket(item.id)}>DELETE</button>

    </div>

}


const Basket = () => {

    const [basket, saveBasket] = useLocalStorage("basket", [])

    const [total, setTotal] = useState(0) 
    const [products, setProducts] = useState([]);
    const {data, fetchData} = useTinyFetch();


    useEffect( () => {

        fetchData("/products");

    }, [])

    useEffect( () => {

        if(data.length !== 0)
        {
            setProducts(data)
        }
    
    }, [data])

    useEffect( () => {

        if(basket.length !== 0 && products.length !== 0)
        {
            let sum = 0;

            basket.map( (item) => {

                sum += item.quantity * getProduct(item.id).price;

            } )

            setTotal(sum)
        }


    }, [basket, products]) 


    const getProduct = (id) => {

        return products.find( (product) => product._id === id)

    }


    const addToBasket = (id, quantity = 1) => {

        let basketItemIndex = basket.findIndex( (item) => item.id === id)

        if(basketItemIndex === -1){

            saveBasket([
                ...basket,
                {
                    id,
                    quantity
                }
            ])

        } else {

            basket[basketItemIndex].quantity += quantity;

            let sum = basket[basketItemIndex].quantity * getProduct(id).price;
            setTotal(sum);

            saveBasket([
                ...basket
            ])
        }
    }

    const deleteFromBasket = (id) => {

        let updatedBasketList = basket.filter( (item) => item.id !== id )

        saveBasket([

            ...updatedBasketList

        ])
    }

    const removeFromBasket = (id, quantity = 1) => {

        let basketItemIndex = basket.findIndex( (item) => item.id === id)
        console.log(id, quantity, basketItemIndex)
        if(basketItemIndex !== -1)
        {
            basket[basketItemIndex].quantity -= quantity;

            let sum = basket[basketItemIndex].quantity * getProduct(id).price;
            setTotal(sum);

            if(basket[basketItemIndex].quantity === 0)
            {

                deleteFromBasket(id)

            } else {
                saveBasket([

                    ...basket
    
                ])
            }

     
        }

        
    }

    const submitOrder = async () => {

        let postObject = {
            products : basket,
            email: "anders@mediiacollege.dk",
            total : total
        }

        console.log('postObject', postObject)

        const response = await fetch("http://localhost:3042/order", {
            "method" : "POST",
            "headers" : {
                "content-type" : "application/json"
            },
            "body" : JSON.stringify(postObject)
        });

        const result = await response.json();

    }

    return (
        <div className={styles.basket}>

            <h2>Basket Komponent {basket.length} {products.length}</h2>
        
            <div>

                {products.length !== 0 && basket.map( (item) => {

                    let product = getProduct(item.id)
                
                    return <BasketItem key={item.id} item={item} addToBasket={addToBasket} removeFromBasket={removeFromBasket} deleteFromBasket={deleteFromBasket} product={product}></BasketItem>

                })}

                <h3>Total : {total} kr.</h3>
       
                <button onClick={submitOrder}>Submit Order</button>

            </div>
        </div>
    );
};
export default Basket;