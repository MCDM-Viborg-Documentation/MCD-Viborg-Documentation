```
Author      : Media College
Department  : WEB 
Year        : 2024 
Description : Mediacollege + vite + react.        
```

## Kom igang.

Dette er en mcd_web_tutorial_client - template med det mest essentielle for at udvikle "legekrogen" tutorials.

1. Installer pakker.

    ```
    npm install
    ```

2. Start Dev server.

    ```
    npm run dev
    ```


## Klargør til server.


1. Start Build.

    ```
    npm run build
    ```

2. Test Build.

    ```
    npm run start
    ```
