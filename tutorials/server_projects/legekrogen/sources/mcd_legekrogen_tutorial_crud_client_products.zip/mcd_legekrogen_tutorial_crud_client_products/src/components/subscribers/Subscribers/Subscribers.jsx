import { useEffect, useState } from 'react';
import PrintJson from '../../common/PrintJSON/PrintJson';
import styles from './subscribers.module.css'
import useTinyFetch from '../../../hooks/tinyFetch.hook';

const Subscriber = ({subscriber}) => {

    return <div className={styles.subscriber}>
        
        <PrintJson jsonobj={subscriber} headline={subscriber.name}></PrintJson>
        
    </div>

}

const SubscribersList = ({subscribers}) => {

    return (
        <div className={styles.list}>

            {subscribers.map( (subscriber) => {

                return <Subscriber key={subscriber._id} subscriber={subscriber}></Subscriber>

            } )}

        </div>
    )

}

const Subscribers = () => {

    const [subscribers, setSubscribers] = useState([]);
    const {data, fetchData} = useTinyFetch();

    useEffect( () => {

        fetchData('/subscribers');

    }, [])

    useEffect( () => {

        setSubscribers(data)
        
    }, [data])

    return (
        <div className={styles.subscribers}>
            <SubscribersList subscribers={subscribers}></SubscribersList>
        </div>
    );

};
export default Subscribers;