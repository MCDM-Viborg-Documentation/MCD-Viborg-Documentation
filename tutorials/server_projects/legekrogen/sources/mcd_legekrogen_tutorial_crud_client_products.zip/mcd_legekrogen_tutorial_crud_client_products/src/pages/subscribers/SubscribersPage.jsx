import Subscribers from "../../components/subscribers/Subscribers/Subscribers"

const SubscribersPage = () => {

    return (
        <div>
            <Subscribers></Subscribers>
        </div>
    )

}

export default SubscribersPage