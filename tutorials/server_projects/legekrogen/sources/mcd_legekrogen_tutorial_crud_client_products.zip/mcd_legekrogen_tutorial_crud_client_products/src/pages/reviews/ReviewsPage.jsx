import Reviews from "../../components/reviews/Reviews/Reviews"

const ReviewsPage = () => {

    return (
        <div>
            <Reviews></Reviews>
        </div>
    )

}

export default ReviewsPage