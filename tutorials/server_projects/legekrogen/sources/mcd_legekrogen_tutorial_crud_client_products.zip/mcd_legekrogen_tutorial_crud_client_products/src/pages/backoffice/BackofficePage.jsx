import { Outlet } from 'react-router-dom';
import BoNavigation from '../../components/backoffice/Navigation/BoNavigation';
import styles from './backofficePage.module.css'
const BackofficePage = () => {
    return (
        <div className={styles.page}>
            <BoNavigation></BoNavigation>

            <div className={styles.outlet}>

                <Outlet></Outlet>

            </div>
            
        </div>
    );
};
export default BackofficePage;